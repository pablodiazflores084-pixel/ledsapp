package com.luces.led

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import android.widget.Toast

class LightWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val views = RemoteViews(ctx.packageName, R.layout.widget)
        views.setOnClickPendingIntent(R.id.btn_on, pending(ctx, ACTION_ON))
        views.setOnClickPendingIntent(R.id.btn_off, pending(ctx, ACTION_OFF))
        mgr.updateAppWidget(ids, views)
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        val data = when (intent.action) {
            ACTION_ON -> BleController.ON
            ACTION_OFF -> BleController.OFF
            else -> return
        }
        val mac = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE).getString("mac", null)
        if (mac == null) {
            Toast.makeText(ctx, "Abre la app y elige tus luces primero", Toast.LENGTH_LONG).show()
            return
        }
        val result = goAsync()
        BleController.send(ctx, mac, data) { ok ->
            if (!ok) Toast.makeText(ctx, "No se pudo conectar con las luces", Toast.LENGTH_SHORT).show()
            result.finish()
        }
    }

    private fun pending(ctx: Context, action: String): PendingIntent {
        val i = Intent(ctx, LightWidget::class.java).setAction(action)
        return PendingIntent.getBroadcast(
            ctx, action.hashCode(), i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    companion object {
        const val ACTION_ON = "com.luces.led.ON"
        const val ACTION_OFF = "com.luces.led.OFF"
    }
}
