package com.luces.led

import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.util.UUID

/**
 * Envía un comando BLE a la tira LED y se desconecta.
 * Protocolo tipo ELK-BLEDOM (el más común en tiras "Lotus Lamp X").
 * Si tu tira no responde, cambia ON / OFF / UUIDs aquí.
 */
@SuppressLint("MissingPermission")
object BleController {
    val SERVICE: UUID = UUID.fromString("0000fff0-0000-1000-8000-00805f9b34fb")
    val CHARACTERISTIC: UUID = UUID.fromString("0000fff3-0000-1000-8000-00805f9b34fb")

    private fun b(vararg v: Int) = ByteArray(v.size) { v[it].toByte() }

    val ON = b(0x7E, 0x04, 0x04, 0xF0, 0x00, 0x01, 0xFF, 0x00, 0xEF)
    val OFF = b(0x7E, 0x04, 0x04, 0x00, 0x00, 0x00, 0xFF, 0x00, 0xEF)

    fun send(ctx: Context, mac: String, data: ByteArray, done: (Boolean) -> Unit) {
        val handler = Handler(Looper.getMainLooper())
        var finished = false
        var ok = false
        var gatt: BluetoothGatt? = null

        fun finish() {
            if (finished) return
            finished = true
            try { gatt?.close() } catch (_: Exception) {}
            done(ok)
        }

        val adapter = ctx.getSystemService(BluetoothManager::class.java)?.adapter
        if (adapter == null || !adapter.isEnabled) { done(false); return }

        val callback = object : BluetoothGattCallback() {
            override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
                if (newState == BluetoothProfile.STATE_CONNECTED) g.discoverServices()
                else if (newState == BluetoothProfile.STATE_DISCONNECTED) handler.post { finish() }
            }

            override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
                val c = g.getService(SERVICE)?.getCharacteristic(CHARACTERISTIC)
                if (c == null) { g.disconnect(); return }
                if (Build.VERSION.SDK_INT >= 33) {
                    g.writeCharacteristic(c, data, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)
                } else {
                    c.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                    c.value = data
                    g.writeCharacteristic(c)
                }
            }

            override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
                ok = status == BluetoothGatt.GATT_SUCCESS
                g.disconnect()
            }
        }

        gatt = adapter.getRemoteDevice(mac).connectGatt(ctx, false, callback, BluetoothDevice.TRANSPORT_LE)
        handler.postDelayed({ finish() }, 8000) // tiempo máximo
    }
}
