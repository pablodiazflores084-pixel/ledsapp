package com.luces.led

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*

@SuppressLint("MissingPermission")
class MainActivity : Activity() {
    private val found = LinkedHashMap<String, String>() // mac -> nombre
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var status: TextView
    private var scanning = false

    private val scanCb = object : ScanCallback() {
        override fun onScanResult(type: Int, r: ScanResult) {
            val name = r.device.name ?: return
            if (found.put(r.device.address, name) == null) refreshList()
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }

        status = TextView(this).apply { textSize = 16f }
        val scanBtn = Button(this).apply { text = "Buscar luces"; setOnClickListener { startScan() } }
        val list = ListView(this)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, ArrayList())
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            val mac = found.keys.elementAt(pos)
            prefs().edit().putString("mac", mac).apply()
            updateStatus()
        }
        val row = LinearLayout(this)
        val on = Button(this).apply { text = "Probar: encender"; setOnClickListener { test(BleController.ON) } }
        val off = Button(this).apply { text = "Probar: apagar"; setOnClickListener { test(BleController.OFF) } }
        row.addView(on, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(off, LinearLayout.LayoutParams(0, -2, 1f))

        root.addView(status); root.addView(scanBtn); root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f)); root.addView(row)
        root.addView(TextView(this).apply {
            text = "Después, mantén pulsado el escritorio → Widgets → Luces LED."
        })
        setContentView(root)
        updateStatus()
        requestPerms()
    }

    private fun prefs() = getSharedPreferences("prefs", MODE_PRIVATE)

    private fun updateStatus() {
        status.text = "Luces seleccionadas: " + (prefs().getString("mac", null) ?: "ninguna")
    }

    private fun refreshList() {
        adapter.clear()
        adapter.addAll(found.map { "${it.value}  (${it.key})" })
    }

    private fun test(cmd: ByteArray) {
        val mac = prefs().getString("mac", null) ?: return toast("Elige unas luces primero")
        BleController.send(this, mac, cmd) { ok -> if (!ok) toast("No se pudo conectar") }
    }

    private fun startScan() {
        if (!hasPerms()) return requestPerms()
        val scanner = getSystemService(BluetoothManager::class.java).adapter?.bluetoothLeScanner
            ?: return toast("Activa el Bluetooth")
        if (scanning) return
        found.clear(); refreshList()
        scanning = true
        scanner.startScan(scanCb)
        toast("Buscando 10 segundos… (cierra la app LotusLamp si está conectada)")
        Handler(Looper.getMainLooper()).postDelayed({ scanner.stopScan(scanCb); scanning = false }, 10000)
    }

    private fun perms() =
        if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    private fun hasPerms() = perms().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
    private fun requestPerms() { if (!hasPerms()) requestPermissions(perms(), 1) }
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
